package com.example.kiltavafinal.data.model

import com.example.kiltavafinal.data.model.Movie

data class MovieResponse(
    val results: List<Movie>
)